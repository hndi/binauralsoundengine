/***************************************************************
 * Name:      BinauralFilterGUIApp.h
 * Purpose:   Defines Application Class
 * Author:    hndi ()
 * Created:   2020-08-04
 * Copyright: hndi ()
 * License:
 **************************************************************/

#ifndef BINAURALFILTERGUIAPP_H
#define BINAURALFILTERGUIAPP_H

#include <wx/app.h>

class BinauralFilterGUIApp : public wxApp
{
    public:
        virtual bool OnInit();

};

#endif // BINAURALFILTERGUIAPP_H
