#ifndef GUIHELPERS_H
#define GUIHELPERS_H
#include <wx/wx.h>

wxString fToStr(double n);

#endif // GUIHELPERS_H
