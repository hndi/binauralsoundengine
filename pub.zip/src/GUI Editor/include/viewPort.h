#ifndef VIEWPORT_H
#define VIEWPORT_H


class viewPort
{
    public:
        viewPort();
        ~viewPort();

    protected:

    private:
};

#endif // VIEWPORT_H
